from django.shortcuts import get_object_or_404
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.template import Context, loader
from django.http import HttpResponseRedirect, HttpResponse, Http404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from django.utils import simplejson
from models import *
from forms import *

# Create your views here.
@login_required()
def ajax_get_selection_json(request):
    session = Session.objects.get(pk=request.COOKIES['sessionid']).get_decoded()
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    term = request.GET['term']
    target = request.GET['target']
    ret = []
    if target == 'member':
        possible_member = Member.objects.filter(user=my_user).filter(
                            name__startswith=term)
        for mem in possible_member :
            ret.append({'value':mem.name,'label':mem.__unicode__()})
    elif target == 'group':
        possible_group = MemberGroup.objects.filter(user=my_user).filter(
                            name__startswith=term)
        for group in possible_group :
            ret.append({'value':group.__unicode__(),
                'label':'{0}({1})'.format(group.__unicode__(),
                    Member.objects.filter(user=my_user, group=group).__len__())})

    return HttpResponse(simplejson.dumps(ret), 
        mimetype='application/javascript' )

#@login_required()
#def ajax_get_group(request):
#    session = Session.objects.get(pk=request.COOKIES['sessionid']).get_decoded()
#    my_user = User.objects.get(pk=str(session['_auth_user_id']))
#    term = request.GET['term']
#    term = request.GET['term'].split(';')[-1].strip()
#    ret = []
#    return HttpResponse(simplejson.dumps(ret), 
#        mimetype='application/javascript' )


@login_required()
def member(request):
    session = Session.objects.get(pk=request.COOKIES['sessionid']).get_decoded()
    # {'_auth_user_id': 5L, 
    # '_auth_user_backend': 'django.contrib.auth.backends.ModelBackend'}
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    member = Member.objects.filter(user=my_user)
    my_member_form = MemberForm()
    my_member_form.set_user_member_group(my_user)
    my_group_form = MemberGroupForm()
    my_group_form.set_user(my_user)
    return render_to_response('MyUser/member.html',{
            'members':member,
            'new_member_form':my_member_form,
            'new_group_form':my_group_form},
        context_instance=RequestContext(request))

@login_required()
def show_all_member(request):
    session = Session.objects.get(pk=request.COOKIES['sessionid']).get_decoded()
    # {'_auth_user_id': 5L, 
    # '_auth_user_backend': 'django.contrib.auth.backends.ModelBackend'}
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    member = Member.objects.filter(user=my_user)
    return render_to_response('MyUser/show_all_member.html',{'members':member},
        context_instance=RequestContext(request))


@login_required()
def ajax_add_member(request):
    session = Session.objects.get(
        pk=request.COOKIES['sessionid']).get_decoded()
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    if request.method == 'POST' :
        my_member_form = MemberForm(request.POST)
        if my_member_form.is_valid():
            my_member_form.save()
            return HttpResponse(simplejson.dumps({'result':1}),
                mimetype='application/javascript')
        else:
            return HttpResponse(simplejson.dumps(
                {'result':0,'errors':my_member_form.errors}),
                mimetype='application/javascript')

@login_required()
def add_member(request):
    session = Session.objects.get(
        pk=request.COOKIES['sessionid']).get_decoded()
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    if request.method == 'POST' :
        my_member_form = MemberForm(request.POST)
        if my_member_form.is_valid():
            my_member_form.save()
            return HttpResponseRedirect('/member/')
        else:
            return render_to_response(
                'MyUser/edit_member.html',{'form':my_member_form},
                context_instance=RequestContext(request))
    else:
        my_member_form = MemberForm()
        my_member_form.set_user_member_group(my_user)
        return render_to_response('MyUser/edit_member.html',
                {'form':my_member_form},
                context_instance=RequestContext(request))

@login_required()
def edit_member(request, member_id):
    session = Session.objects.get(
            pk=request.COOKIES['sessionid']).get_decoded()
    # {'_auth_user_id': 5L, 
    # '_auth_user_backend': 'django.contrib.auth.backends.ModelBackend'}
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    if request.method == 'POST' :
        my_member = Member.objects.get(
                pk=member_id, user=my_user)
        my_member_form = MemberForm(request.POST, instance=my_member)
        if my_member_form.is_valid():
            #cleaned_data = my_member_form.cleaned_data
            #my_member = Member(user=my_user, 
            #        name = cleaned_data['name'],
            #        phone = cleaned_data['phone'])
            my_member_form.save()
            return HttpResponseRedirect('/member/')
        else:
            return render_to_response(
                'MyUser/edit_member.html',{'form':my_member_form},
                context_instance=RequestContext(request))
    else:
        try:
            my_member = Member.objects.get(
                pk=member_id, user=my_user)
            my_form = MemberForm(instance=my_member)
            my_form.set_user_member_group(my_user)
            return render_to_response(
                'MyUser/edit_member.html',
                {'form':my_form},
                context_instance=RequestContext(request))
        except:
            # TODO:if user intend to edit member is not belong to him,
            # will come to here
            pass

@login_required()
def delete_member(request, member_id):
    session = Session.objects.get(
        pk=request.COOKIES['sessionid']).get_decoded()
    # {'_auth_user_id': 5L, 
    # '_auth_user_backend': 'django.contrib.auth.backends.ModelBackend'}
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    if request.method == 'POST' :pass
    else:
        try:
            my_member = Member.objects.get(
                pk=member_id, user=my_user)
            my_member.delete()
            return HttpResponseRedirect('/member/')
        except:
            # TODO:if user intend to delete member is not belong to him,
            # will come to here
            pass


@login_required()
def ajax_add_group(request):
    session = Session.objects.get(
        pk=request.COOKIES['sessionid']).get_decoded()
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    if request.method == 'POST' :
        my_group_form = MemberGroupForm(request.POST)
        if my_group_form.is_valid():
            my_group_form.save()
            return HttpResponse(simplejson.dumps({'result':1}),
                mimetype='application/javascript')
        else:
            return HttpResponse(simplejson.dumps(
                {'result':0,'errors':my_group_form.errors}),
                mimetype='application/javascript')

@login_required()
def add_group(request):
    session = Session.objects.get(
        pk=request.COOKIES['sessionid']).get_decoded()
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    if request.method == 'POST' :
        my_group_form = MemberGroupForm(request.POST)
        if my_group_form.is_valid():
            my_group_form.save()
            return HttpResponseRedirect('/member/')
        else:
            return render_to_response(
                'MyUser/edit_group.html',{'form':my_group_form},
                context_instance=RequestContext(request))
    else:
        my_group_form = MemberGroupForm()
        my_group_form.set_user(my_user)
        return render_to_response('MyUser/edit_group.html',
                {'form':my_group_form},
                context_instance=RequestContext(request))

@login_required()
def edit_group(request, group_id):
    session = Session.objects.get(
            pk=request.COOKIES['sessionid']).get_decoded()
    # {'_auth_user_id': 5L, 
    # '_auth_user_backend': 'django.contrib.auth.backends.ModelBackend'}
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    if request.method == 'POST' :
        my_group = MemberGroup.objects.get(
                pk=group_id, user=my_user)
        my_group_form = MemberGroupForm(request.POST, 
            instance=my_group)
        if my_group_form.is_valid():
            my_group_form.save()
            return HttpResponseRedirect('/member/')
        else:
            return render_to_response(
                'MyUser/edit_group.html',{'form':my_group_form},
                context_instance=RequestContext(request))
    else:
        try:
            my_group = MemberGroup.objects.get(
                pk=group_id, user=my_user)
            my_form = MemberGroupForm(instance=my_group)
            my_form.set_user(my_user)
            return render_to_response(
                'MyUser/edit_group.html',
                {'form':my_form},
                context_instance=RequestContext(request))
        except:
            # TODO:if user intend to edit group is not belong to him,
            # will come to here
            pass

@login_required()
def delete_group(request, group_id):
    session = Session.objects.get(
        pk=request.COOKIES['sessionid']).get_decoded()
    # {'_auth_user_id': 5L, 
    # '_auth_user_backend': 'django.contrib.auth.backends.ModelBackend'}
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    if request.method == 'POST' :pass
    else:
        try:
            my_group = MemberGroup.objects.get(
                pk=group_id, user=my_user)
            my_group.delete()
            return HttpResponseRedirect('/member/')
        except:
            # TODO:if user intend to delete group is not belong to him,
            # will come to here
            pass
