from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save

def create_default_member_group(sender, **kwargs):
    """When creating a new user, make a default member group for him or her."""
    u = kwargs["instance"]
    if not MemberGroup.objects.filter(user=u):
        MemberGroup(user=u,name='Default').save()

post_save.connect(create_default_member_group, sender=User)

# Create your models here.
class MemberGroup(models.Model):
    user = models.ForeignKey(User)
    name = models.CharField(max_length=30)

    def __unicode__(self):
        return self.name


class Member(models.Model):
    user = models.ForeignKey(User)
    name = models.CharField(max_length=30)
    phone = models.CharField(max_length=10)
    group = models.ForeignKey(MemberGroup)

    def __unicode__(self):
        return 'Member {0}, phone number is {1}, in Group {2}'.format(
            self.name, self.phone, self.group)
