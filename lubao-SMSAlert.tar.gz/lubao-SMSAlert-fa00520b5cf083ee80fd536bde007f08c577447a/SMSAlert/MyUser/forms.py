from django.contrib.auth.models import User
from django.forms import ModelForm 
from django import forms 
from models import *

class MemberGroupForm(ModelForm):
    '''
    This class will present member's information
    '''
    name = forms.CharField(max_length=30, required=True,
        help_text='No longer than 30 words.')
   
    class Meta:
        model = MemberGroup
    
    def set_user(self, user):
        self.fields['user'] = forms.IntegerField(
            widget=forms.HiddenInput, required=True, initial=user.pk)
    
    def clean(self):
        cleaned_data = self.cleaned_data
        name = cleaned_data['name']
        user = cleaned_data['user']
        if MemberGroup.objects.filter(user=user, name=name).exists():
            self._errors["name"] = self.error_class(
                ['Group name,{0}, exists.'.format(name)])
            del cleaned_data["name"]
        
        return cleaned_data


class MemberForm(ModelForm):
    '''
    This class will present member information
    '''
    name = forms.CharField(max_length=30, required=True)
    phone = forms.RegexField(r'\d{10}', required=True,
        help_text='Please input 10 digits phone number.')
   
    class Meta:
        model = Member
    
    def set_user_member_group(self, user):
        self.fields['group'].queryset = MemberGroup.objects.filter(user=user)
        self.fields['user'] = forms.IntegerField(
            widget=forms.HiddenInput, required=True, initial=user.pk)

    def clean(self):
        cleaned_data = self.cleaned_data
        name = cleaned_data['name']
        user = cleaned_data['user']
        if Member.objects.filter(user=user, name=name).exists():
            self._errors["name"] = self.error_class(
                ['Member name exists.'])
            del cleaned_data["name"]
        
        return cleaned_data
