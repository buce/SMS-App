from django.forms import ModelForm 
from django import forms 
from models import *

class AlertForm(ModelForm):
    '''
    The Form will present Alert's data
    '''
    class Meta:
        model = Alert
        exclude = ('sent_time','status','sent_by')
