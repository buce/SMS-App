from jabberbot import JabberBot, botcmd
