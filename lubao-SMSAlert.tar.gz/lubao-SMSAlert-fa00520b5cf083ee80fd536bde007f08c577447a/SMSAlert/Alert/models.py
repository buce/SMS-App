from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class AlertLog(models.Model):
    '''
    Log each alert into database
    '''
    STATUS_CHOICE = ( 
    ('0','Not Sent'),
    ('1','Sent'),
    )
    receiver = models.TextField()
    content = models.TextField()
    result = models.TextField()
    sent_by = models.ForeignKey(User)
    is_group = models.BooleanField(default=False)
    status = models.CharField(max_length=2, choices=STATUS_CHOICE, default='0')
    scheudle_time = models.DateTimeField(null=True)
    sent_time = models.DateTimeField(null=True)
    create_time = models.DateTimeField(auto_now_add=True)
