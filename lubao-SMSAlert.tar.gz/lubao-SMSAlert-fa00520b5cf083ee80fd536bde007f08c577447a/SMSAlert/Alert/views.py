from django.shortcuts import get_object_or_404
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.template import Context, loader
from django.http import HttpResponseRedirect, HttpResponse, Http404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from django.utils import simplejson
from models import *
from MyUser.models import *
import os
import time
from jabberbot import JabberBot
# Create your views here.
_PATH_TO_SMSD_CONFIGURE = os.path.join(os.path.dirname(__file__),'smsdrc') 
username = 'SmsAlertClientBot@gmail.com'
password = 'SmsAlertBot'
__BOT = JabberBot(username, password)
__BOT.connect()
__GATEWAY_BOT = 'smsalertserverbot@gmail.com'
__KEY = 'message_for_gammu '

@login_required()
def home(request):
    session = Session.objects.get(pk=request.COOKIES['sessionid']).get_decoded()
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    return render_to_response('Alert/message.html',
        {'alert_logs':AlertLog.objects.filter(sent_by=my_user)},
        context_instance=RequestContext(request))

@login_required()
def ajax_send_text(request):
    if request.method == 'GET':
        return Http404
    session = Session.objects.get(pk=request.COOKIES['sessionid']).get_decoded()
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    content = request.POST['message']
    res_status = 1
    res=[]
    to=[]
    is_group = False
    if request.POST.__contains__('members'):
        members = [member.strip() \
		for member in request.POST['members'].split(';')]
        for member in members:
            if member != '':
                try:
                    to.append(Member.objects.get(
                            name=member, user=my_user)
                        )
                except Exception as inst:
                    res.append('Member \'{0}\' does not exist'.format(member))
                    res_status = 0
                    pass

    if res_status == 0:
        return HttpResponse(simplejson.dumps({'result':'\n'.join(res)}),
            mimetype='application/javascript')
    
    if request.POST.__contains__('groups'):
        is_group = True
        groups = [group.strip() for group in request.POST['groups'].split(';')]
        for group in groups:
            if group != '':
                try:
                    all_member = Member.objects.filter(
                        user=my_user, 
                        group=MemberGroup.objects.get(user=my_user,name=group)
                    )
                    for member in all_member:
                        if member not in to:
                            to.append(member)
                except Exception as inst:
                    res.append('Group \'{0}\' does not exist'.format(group))
                    res_status = 0
                    pass
    
    if res_status == 0:
        return HttpResponse(simplejson.dumps({'result':'\n'.join(res)}),
            mimetype='application/javascript')

    message_list=[]
    for recv in to:
        try:
            #TODO: what if content longer than 140/160 bytes?
            message = {'SMSC':{'Location':1},'Text':'','Number':''}
            message['Text'] = content
            message['Number'] = recv.phone
            message_list.append(message)
            #ret = gammu_machine.SendSMS(message)
        except Exception as inst:
            res.append('Error: {0}'.format(inst))
    
    msg = __KEY + simplejson.dumps(message_list)
    __BOT.send(__GATEWAY_BOT, msg)
    res.append('Sent to Gateway!')
    

    alert_log = AlertLog(
        receiver=','.join([recv.name for recv in to]),
        content=content,
        sent_by = my_user,
        is_group = is_group,
        status = res_status,
        result = '. '.join(res)
    )
    alert_log.save()
    return HttpResponse(simplejson.dumps({'result':'\n'.join(res)}),
        mimetype='application/javascript')


@login_required()
def send_text(request):
    if request.method == 'GET':
        return Http404
    session = Session.objects.get(pk=request.COOKIES['sessionid']).get_decoded()
    my_user = User.objects.get(pk=str(session['_auth_user_id']))
    content = request.POST['message']
    res=[]
    to=[]
    is_group = False
    if request.POST.__contains__('members'):
        members = [member.strip() \
		for member in request.POST['members'].split(';')]
        members.pop() # remove the last one which is u''
        for member in members:
            to.append(Member.objects.get(
                    name=member, user=my_user)
                )
    if request.POST.__contains__('groups'):
        is_group = True
        groups = [group.strip() for group in request.POST['groups'].split(';')]
        groups.pop() # remove the last one which is u''
        for group in groups:
            try:
                all_member = Member.objects.filter(
                    user=my_user, 
                    group=MemberGroup.objects.get(user=my_user,name=group)
                )
                for member in all_member:
                    if member not in to:
                        to.append(member)
            except Exception as inst:
                res.append('Error: {0}'.format(inst))
                pass
#    path_to_config = os.path.join(os.path.dirname(__file__),'gammurc')
#    gammu_machine = gammu.StateMachine()
#    gammu_machine.ReadConfig(Filename=path_to_config)
#    gammu_machine.Init()
    #try:
        #gammu_smsd = gammu.SMSD(Config=_PATH_TO_SMSD_CONFIGURE)
    #except:
        #gammu_smsd = None
#    message = {'SMSC':{'Location':1},'Text':'','Number':''}
    res_status = 1
    message_list=[]
    for recv in to:
        try:
            #TODO: what if content longer than 140/160 bytes?
            message = {'SMSC':{'Location':1},'Text':'','Number':''}
            message['Text'] = content
            message['Number'] = recv.phone
            message_list.append(message)
            #ret = gammu_machine.SendSMS(message)
        except Exception as inst:
            res.append('Error: {0}'.format(inst))
    try:
        #ret = gammu_smsd.InjectSMS(message_list)
        res.append('Sucessfully send message.')
    except Exception as inst:
        res.append('Error: {0}'.format(inst))
        res_status = 0
    

    alert_log = AlertLog(
        receiver=','.join([recv.name for recv in to]),
        content=content,
        sent_by = my_user,
        is_group = is_group,
        status = res_status,
        result = '. '.join(res)
    )
    alert_log.save()
    return HttpResponseRedirect('/message/')

@login_required()
def show_log_content(request, log_id):
    alert_log = AlertLog.objects.get(pk=log_id)
    return render_to_response('Alert/show_alert_log.html',{'alert_log':alert_log},
        context_instance=RequestContext(request))
