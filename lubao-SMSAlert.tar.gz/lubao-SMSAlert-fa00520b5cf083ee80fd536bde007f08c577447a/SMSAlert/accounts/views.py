from django.template import RequestContext
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from forms import *
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session

# Create your views here.
@login_required()
def user_profile(request):
    session = Session.objects.get(pk=request.COOKIES['sessionid']).get_decoded()
    # {'_auth_user_id': 5L, 
    # '_auth_user_backend': 'django.contrib.auth.backends.ModelBackend'}
    user = User.objects.get(id=str(session['_auth_user_id']))
    if request.method == 'POST':pass
    else:
        form = UserProfileForm(
            instance=UserProfile(user=user)) 
        return render_to_response(
                'accounts/profile.html',
                {'form':form,'user':user},
            context_instance=RequestContext(request)
        ) 
