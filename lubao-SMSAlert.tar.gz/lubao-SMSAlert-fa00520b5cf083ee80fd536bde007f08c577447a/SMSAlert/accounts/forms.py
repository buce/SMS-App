from django.forms import ModelForm 
from django import forms 
from models import * 

class UserProfileForm(ModelForm):
    '''
    The Form will present User Profile 
    '''
    phone = forms.RegexField(r'\d{10}', required=True,
        help_text='Please input 10 digits phone number.')
    
    class Meta:
        model = UserProfile
        exclude = ('user')
