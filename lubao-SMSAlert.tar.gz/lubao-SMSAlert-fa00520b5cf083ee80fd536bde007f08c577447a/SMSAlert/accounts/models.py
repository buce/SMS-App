from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from MyUser.models import MemberGroup
def create_user_defalt_member_group(sender, **kwargs):
    """When creating a new user, make a profile for him or her."""
    u = kwargs["instance"]
    if not UserProfile.objects.filter(user=u):
        UserProfile(user=u).save()
    if not MemberGroup.objects.filter(user=u):
        MemberGroup(user=u,name='Default').save()

post_save.connect(create_user_profile_member_group, sender=User)

# Create your models here.
class UserProfile(models.Model):
    '''
    This class will present User Profile
    beside auth.user
    '''
    # This is the only required field
    user = models.ForeignKey(User, unique=True)

    # Additional fields for user
    phone = models.CharField(max_length=10)
