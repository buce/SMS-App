#!/usr/bin/env python
from jabberbot import JabberBot, botcmd
import datetime, os
import gammu
from django.utils import simplejson
from GammuDB import gammu_sql_eng
class GammuTextBot(JabberBot):

    _PATH_TO_SMSD_CONFIGURE = os.path.join(os.path.dirname(__file__),'smsdrc')
    _gammu_smsd = gammu.SMSD(Config=_PATH_TO_SMSD_CONFIGURE)
    _gammu_sql = gammu_sql_eng()
    @botcmd
    def whoami(self, mess, args):
        ret = str(mess.getFrom())
        self.send(ret, ret)
    
    @botcmd
    def help(self, mess, args):
        return '''Usage: text [phone number] : [message] '''        

    @botcmd
    def gateway_status(self, mess, args):
        return str(self._gammu_smsd.GetStatus())

    @botcmd
    def text(self, mess, args):
        # args will be a message w/o command
        try:
            args = args.strip().split(':')
            content = args[1].strip()
            phone = args[0].strip()
            message = {'SMSC':{'Location':1},'Text':'','Number':''}
            message['Text'] = content
            message['Number'] = phone
            #print message
            ret = self._gammu_smsd.InjectSMS([message])
            #ret = self._gammu_sql.exeSQL(
            #    self._gammu_sql.getInsertSentBox(phone, content))
            return 'Sucessfully send message {0} to {1}'.format(content, phone)
        except Exception as inst:
            return 'Error: {0}'.format(inst)
            

    @botcmd
    def message_for_gammu(self, mess, args):
        # args will be a message w/o command
        try:
            message = simplejson.loads(args)
            print message
            ret = self._gammu_smsd.InjectSMS(message)
            return 'Inject to DB.'
        except Exception as inst:
            return 'Error: {0}'.format(inst)
        


username = 'SmsAlertServerBot@gmail.com'
password = 'SmsAlertBot'
bot = GammuTextBot(username, password, debug=True)
#print bot.connect()
bot.serve_forever()
