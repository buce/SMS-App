#!/usr/bin/env python
import MySQLdb
class gammu_sql_eng():
    def exeSQL(self, SQL):
        try:
            conn=MySQLdb.connect(host = 'localhost',
                                 user = 'gammu',
                                 passwd = 'smsd',
                                 )
            cursor=conn.cursor()
            cursor.execute(SQL)
            ret=cursor.fetchall()
            cursor.close()
            conn.commit()
            conn.close()
            return ret
        except MySQLdb.Error ,e:
            #ret="Error %d: %s".format(e.args[0],e.args[1])
            return False

    def getInsertSentBox(self, to,mesg):
        return '''
        INSERT INTO `gammu_smsd`.`outbox` (
        `UpdatedInDB` ,
        `InsertIntoDB` ,
        `SendingDateTime` ,
        `Text` ,
        `DestinationNumber` ,
        `Coding` ,
        `UDH` ,
        `Class` ,
        `TextDecoded` ,
        `ID` ,
        `MultiPart` ,
        `RelativeValidity` ,
        `SenderID` ,
        `SendingTimeOut` ,
        `DeliveryReport` ,
        `CreatorID`
        )
        VALUES (
        CURRENT_TIMESTAMP , 
        '0000-00-00 00:00:00', 
        '0000-00-00 00:00:00', 
        '{0}', '{1}', '', 'Default_Compression', 
        '', '', NULL , 'false', '-1', NULL , 
        '0000-00-00 00:00:00', 'default', ''
        )'''.format(mesg,to)
