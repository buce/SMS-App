#!/usr/bin/env python
import gammu
import os
import thread
#def start_gammu_smsd():
path_to_config = os.path.join(os.path.dirname(__file__),'smsdrc')
_SMSD_ = gammu.SMSD(Config=path_to_config)
_SMSD_.MainLoop(MaxFailures=1)

#thread.start_new_thread(start_gammu_smsd,())
